#!/usr/bin/env python3


'''
* Team Id : LD_2428
* Author List : Sriram Thangavel R, Akshith S, Dinesh Kumar S, Bharanidharan S
* Filename: Task_6.py
* Theme: Luminosity Drone (LD) -- eYRC Specific
* Functions: whycon_poses_callback(msg), drone_image_callback(msg), image_processing_thread(msg), find_aliens(current_frame), convert_px_to_deci(x,y), pid(), publish_data_to_rpi(), alien_spotter(), search_algo(), find_closest_coordinate(threshold), find_closest_already_found_aliens_coordinate(threshold), start_gradual_landing(), report_alien(count), alerter(delay), landing(), shutdown_hook(), arm(), disarm(), main(args)
* Global Variables: MIN_ROLL, BASE_ROLL, MAX_ROLL, MIN_PITCH, BASE_PITCH, MAX_PITCH, MIN_THROTTLE, BASE_THROTTLE, MAX_THROTTLE, FLYING_HEIGHT, LANDING_HEIGHT, DRONE_LANDING_POINT, DRONE_WHYCON_POSE, ALIEN_TYPES, ALIEN_MAPPER, FOUNDED_ALIENS_COORDINATES, NO_OF_ALIENS_TO_FIND, ARENA_MAPPED_DATA
'''


# standard imports
import time

# third-party imports
import scipy.signal
import numpy as np
import rclpy
from geometry_msgs.msg import PoseArray
from swift_msgs.msg import PIDError, RCMessage
from swift_msgs.srv import CommandBool
from sensor_msgs.msg import Image
from loc_msg.msg import Biolocation
from cv_bridge import CvBridge
from skimage import measure
import numpy as np
import cv2 
import math
import threading



#Drone and Whycon parameters
MIN_ROLL = 1250
BASE_ROLL = 1514
MAX_ROLL = 1600

MIN_PITCH = 1250
BASE_PITCH = 1487
MAX_PITCH = 1600

MIN_THROTTLE = 1245 
BASE_THROTTLE = 1430
MAX_THROTTLE = 1900

FLYING_HEIGHT = 30
LANDING_HEIGHT = 41
DRONE_LANDING_POINT = [10,10,41]

DRONE_WHYCON_POSE = [[], [], []]


#Aliens and Arena parameters
ALIEN_TYPES = {'unknown':1,'alien_a':2,'alien_b':3,'alien_c':4,'alien_d':5}
ALIEN_MAPPER = {1:'unknown',2:'alien_a',3:'alien_b',4:'alien_c',5:'alien_d'}
FOUNDED_ALIENS_COORDINATES = {}


# No of Aliens to find
NO_OF_ALIENS_TO_FIND = 2


# Arena Mapped Coordinates data
ARENA_MAPPED_DATA = {
    "A1": [-7.539, -7.297, 43.795], 
    "B1": [-3.719, -7.49, 43.275], 
    "C1": [0.098, -7.824, 43.721], 
    "D1": [3.949, -7.861, 42.615], 
    "E1": [7.913, -8.09, 42.892], 
    "E2": [7.875, -4.109, 41.83], 
    "D2": [4.06, -3.923, 41.958], 
    "C2": [0.255, -3.772, 42.445], 
    "B2": [-3.642, -3.717, 44.402], 
    "A2": [-7.204, -3.349, 42.744], 
    "A3": [-6.975, 0.425, 42.505], 
    "B3": [-3.315, 0.253, 42.711], 
    "C3": [0.416, 0.052, 42.3], 
    "D3": [4.186, -0.099, 41.712], 
    "E3": [8.064, -0.26, 42.031], 
    "E4": [8.077, 3.505, 41.176], 
    "D4": [4.455, 3.722, 42.242], 
    "C4": [0.627, 3.847, 42.31], 
    "B4": [-3.111, 4.043, 42.606],
    "A4": [-6.888, 4.229, 43.197], 
    "A5": [-6.782, 8.184, 43.996], 
    "B5": [-2.853, 7.727, 42.03], 
    "C5": [0.798, 7.615, 42.179], 
    "D5": [4.568, 7.421, 41.68], 
    "E5": [8.338, 7.314, 41.666]
    }


class DroneController():
    def __init__(self,node):
        self.node= node
        
        #message types
        self.bridge = CvBridge()
        self.rc_message = RCMessage()
        self.biolocation = Biolocation()
        self.drone_whycon_pose_array = PoseArray()
        self.commandbool = CommandBool.Request()

       
        service_endpoint = "/swift/cmd/arming"
        self.arming_service_client = self.node.create_client(CommandBool,service_endpoint)
       
        #drone parameters
        self.set_points = []
        self.landing_mode = False
        self.index = 0
        self.landed = False

        #alein parameters
        self.aliens = []
        self.no_of_aliens_found = 0
        self.alien_align_set_points = []
        self.alien_align_index = 0
        self.found_alien = False
        self.align_mode = False

       
        self.previous_time = 0.0
        self.last_whycon_pose_received_at = 0


#--------------------------------------------------------variables related to PID Controller---------------------------------------------------------------#
        # Error for roll, pitch and throttle  
        self.error = [0, 0, 0] 

           
        self.Pterm = [0.0,0.0,0.0] # to store the proportional terms of PID
        self.Dterm = [0.0,0.0,0.0]  # to store the derivative terms of PID
        self.Iterm = [0.0,0.0,0.0]  #to store the Integral terms of PID  

       #sample time
        self.sample_time = 0.033

        # Create variables for previous error and sum error
        self.sum_error = [0,0,0]
        self.previous_error = [0.0,0.0,0.0]

        #PID Constants
        self.Kp = [ 752 * 0.01  , 650 * 0.01  , 4.4]
        self.Ki = [ 47 * 0.0002  , 43 * 0.0002  , 50 * 0.001 ]
        self.Kd = [ 3510 * 0.1  , 3310 * 0.1  , 1800 * 0.1]


        #sum error limits
        self.integral_limit = [10000,10000,10000]
#-----------------------------------------------------------------------------------------------------------------------------------#


#-----------------------------------------------------Publishers--------------------------------------------------------------------#
        #Publisher for sending commands to drone 
        self.rc_pub = node.create_publisher(RCMessage, "/swift/rc_command",1)

        #Publisher for sending PID errors
        self.pid_error_pub = node.create_publisher(PIDError, "/luminosity_drone/pid_error",1)     

        #Publisher for sending biolocation 
        self.biolocation_pub = node.create_publisher(Biolocation,"/astrobiolocation", 1) 
#-----------------------------------------------------------------------------------------------------------------------------------#


#-----------------------------------------------------Subscribers-------------------------------------------------------------------#
        #Subscriber for WhyCon 
        self.whycon_sub = node.create_subscription(PoseArray,"/whycon/poses",self.whycon_poses_callback,1)
        

        #Subscriber to drone image
        self.drone_image_sub = node.create_subscription(Image,"/video_frames",self.drone_image_callback,1) #buffer rate

#-----------------------------------------------------------------------------------------------------------------------------------#

     
#----------------------------------------------------Callbacks----------------------------------------------------------------------#
    def whycon_poses_callback(self, msg):
        self.last_whycon_pose_received_at = self.node.get_clock().now().seconds_nanoseconds()[0]
        self.drone_whycon_pose_array = msg

    def drone_image_callback(self,msg):
        image_processing_thread = threading.Thread(target=self.image_processing_thread,args=(msg,))
        image_processing_thread.start()
#-----------------------------------------------------------------------------------------------------------------------------------#
        
    '''
    * Function Name: image_processing_thread
    * Input: msg (ROS2 message containing the image data)
    * Output: None
    * Logic: 
        This function processes the image received from the drone's camera. It converts the image to grayscale, detects aliens in the frame, and calculates the center of the frame.
    * Example Call: 
        image_processing_thread(msg)
    ''' 
    def image_processing_thread(self,msg):
        current_frame = self.bridge.imgmsg_to_cv2(msg,desired_encoding="passthrough")
        current_frame = cv2.cvtColor(current_frame, cv2.COLOR_BGR2GRAY)
        self.aliens = DroneController.find_aliens(current_frame)
        self.frame_center = [current_frame.shape[1] / 2,current_frame.shape[0] / 2]
       
#-----------------------------------------------------------------------------------------------------------------------------------#
    '''
    * Function Name: find_aliens
    * Input: 
        - current_frame: A numpy array representing the current frame/image
    * Output: 
        - organisms: A list containing information about detected organisms. 
                     Each item in the list is a list containing organism type, centroid x-coordinate, and centroid y-coordinate.
    * Logic: 
        This function detects aliens in a given frame by processing LED blobs. 
        It applies Gaussian blur, thresholding, erosion, and dilation to preprocess the frame. 
        Then, it identifies connected components representing LED blobs and calculates their centroids. 
        Depending on the number of LEDs detected, it determines the type of organism and its centroid coordinates. 
        Finally, it returns a list of detected organisms with their types and centroid coordinates.
    * Example Call: 
        frame = <input_frame>
        detected_organisms = find_aliens(frame)
    '''
    @staticmethod
    def find_aliens(current_frame):
        organisms_type = {2: 'alien_a',3: 'alien_b',4: 'alien_c',5: 'alien_d'}
        centroid_coords = [] # List to store centroid coordinates
        led_numbers = [] # List to store LED numbers
        organisms = [] # List to store detected organisms
        clusters = [] # List to store clusters of centroids
        distance_threshold = 180 # Threshold for centroid clustering

        # Applying Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(current_frame, (11, 11), 0)

        # Thresholding the blurred image to reveal light regions
        thresh = cv2.threshold(blurred, 225, 255, cv2.THRESH_BINARY)[1]

        # Performing a series of erosions and dilations to remove small blobs of noise from the thresholded image
        thresh = cv2.erode(thresh, None, iterations=1)
        thresh = cv2.dilate(thresh, None, iterations=2)


        # Performing connected component analysis on the thresholded image
        labels = measure.label(thresh, connectivity=2, background=0)

        # Looping over the unique components
        for label in np.unique(labels):
            # If this is the background label, ignore it
            if label == 0:
                continue

            # Constructing the label mask and count the number of pixels 
            labelMask = np.zeros(thresh.shape, dtype="uint8")
            labelMask[labels == label] = 255
            numPixels = cv2.countNonZero(labelMask)

            # If the number of pixels in the component is sufficiently large, add it to the mask of "large blobs"
            if numPixels > 30:
                # Find the centroid of the current LED
                M = cv2.moments(labelMask)
                if M["m00"] != 0:
                    centroid_x = M["m10"] / M["m00"]
                    centroid_y = M["m01"] / M["m00"]
                    centroid_coords.append([centroid_x, centroid_y])

                    # Extract LED number from the label
                    led_number = label
                    led_numbers.append(led_number)

        #counting leds
        led_count = len(led_numbers)

        #finding organisms and it's centroids
        if led_count in organisms_type:
            centroid_x = np.mean([x[0] for x in centroid_coords]) if not led_count == 0 else None
            centroid_y = np.mean([x[1] for x in centroid_coords]) if not led_count == 0 else None
            organisms.append([organisms_type[led_count],centroid_x,centroid_y])
        else: 
            for centroid in centroid_coords:
                found = False
                for cluster in clusters:
                    if any(np.linalg.norm(np.array(centroid) - np.array(existing_centroid)) < distance_threshold for existing_centroid in cluster):
                        cluster.append(centroid)
                        found = True
                        break
                if not found:
                    clusters.append([centroid])


            # Sorting clusters based on their size
            sorted_clusters = sorted(clusters, key=lambda x: len(x))

            # Processing sorted clusters
            for cluster in sorted_clusters:
                centroid_x = np.mean([x[0] for x in cluster]) if not led_count == 0 else None
                centroid_y = np.mean([x[1] for x in cluster]) if not led_count == 0 else None
                organisms.append([organisms_type.get(len(cluster),'unknown'),centroid_x,centroid_y])

        return organisms


#----------------------------------------------------------------------------------------------------------------------------------------------#
    '''
    * Function Name: convert_px_to_deci
    * Input: 
        - x: X-coordinate in pixels
        - y: Y-coordinate in pixels
    * Output: 
        - A list containing converted X-coordinate and Y-coordinate in decimeters
    * Logic: 
        This function converts pixel coordinates to decimeters based on camera parameters and field of view. 
        It calculates the horizontal and vertical angular resolutions, then computes the pixel size in millimeters. 
        After taking the average of horizontal and vertical pixel sizes, it converts the pixel error to decimeters by multiplying with 2.55 (0.1 for mm to decimeters conversion).
    * Example Call: 
        pixel_x = 320
        pixel_y = 240
        deci_coords = convert_px_to_deci(pixel_x, pixel_y)
    '''

    def convert_px_to_deci(self,x,y):
        # # Camera parameters
        fov_h_deg = 62.2  # Horizontal field of view in degrees
        fov_v_deg = 48.8  # Vertical field of view in degrees
        resolution_width = 640 # Resolution width of the camera
        resolution_height = 480 # Resolution height of the camera

        # Calculate the horizontal and vertical angular resolutions
        angular_resolution_h = fov_h_deg / resolution_width  # Degrees per pixel
        angular_resolution_v = fov_v_deg / resolution_height  # Degrees per pixel

        # Calculate the pixel size in the horizontal direction
        pixel_size_h_mm = math.tan(math.radians(angular_resolution_h / 2)) * 2  # mm per pixel

        # Calculate the pixel size in the vertical direction
        pixel_size_v_mm = math.tan(math.radians(angular_resolution_v / 2)) * 2  # mm per pixel

        # Take the average of the horizontal and vertical pixel sizes
        pixel_size_avg_mm = (pixel_size_h_mm + pixel_size_v_mm) / 2

        # Convert pixel error to decimeters
        x_dm = x * pixel_size_avg_mm * 2.55
        y_dm = y * pixel_size_avg_mm * 2.55
     

        return [x_dm,y_dm]
#---------------------------------------------------------------------------------------------------------------------------------------#
    '''
    * Function Name: pid
    * Input: None
    * Output: None
    * Logic: 
        This function implements a PID (Proportional-Integral-Derivative) algorithm for controlling the drone's movement.
        It calculates the error, derivative, and integral terms for roll, pitch, and throttle based on the drone's position 
        and set points. It then computes the Pterm, Iterm, and Dterm using the PID gains (Kp, Ki, Kd). The actuating velocities 
        (output_roll, output_pitch, output_throttle) are calculated by adding Pterm, Iterm, and Dterm to the base values.
        The function also ensures the actuating velocities are within the permissible range. It publishes the calculated velocities 
        and accumulates errors for integral term computation. Additionally, it handles alien detection, alignment, and landing 
        based on the detected aliens and alignment mode. Finally, it publishes PID errors for monitoring purposes.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.pid()
    '''
    def pid(self):
        # Current time calculation
        self.current_time = time.time()
        self.dt = self.current_time - self.previous_time

        # Check if sample time is reached
        if self.dt >= self.sample_time:
            
            # Calculate errors for Roll, Pitch, and Throttle
            try:
                self.error[0] = self.drone_whycon_pose_array.poses[0].position.x - (self.alien_align_set_points[self.alien_align_index][0] if (self.align_mode) else self.set_points[self.index][0])
                self.error[1] = self.drone_whycon_pose_array.poses[0].position.y - (self.alien_align_set_points[self.alien_align_index][1] if (self.align_mode) else self.set_points[self.index][1])
                self.error[2] = self.drone_whycon_pose_array.poses[0].position.z - (self.alien_align_set_points[self.alien_align_index][2] if (self.align_mode)  else self.set_points[self.index][2])

            except Exception as e:
                self.node.get_logger().error(f"Error while calculating errors: {str(e)}")


            # Proportional term calculation
            self.Pterm[0] = self.error[0] * self.Kp[0]
            self.Pterm[1] = self.error[1] * self.Kp[1]
            self.Pterm[2] = self.error[2] * self.Kp[2]
    
            if self.sum_error[0] > self.integral_limit[0]:
                self.sum_error[0] = self.integral_limit[0]
            if self.sum_error[0] < -self.integral_limit[0]:
                self.sum_error[0] = -self.integral_limit[0]
    
            if self.sum_error[1] > self.integral_limit[1]:
                self.sum_error[1] = self.integral_limit[1]
            if self.sum_error[1] < -self.integral_limit[1]:
                self.sum_error[1] = -self.integral_limit[1]
    
            if self.sum_error[2] > self.integral_limit[2]:
                self.sum_error[2] = self.integral_limit[2]
            if self.sum_error[2] < -self.integral_limit[2]:
                self.sum_error[2] = -self.integral_limit[2] 
    
            # Integral term calculation and limiting
            self.Iterm[0] = self.sum_error[0] * self.Ki[0]
            self.Iterm[1] = self.sum_error[1] * self.Ki[1]
            self.Iterm[2] = self.sum_error[2] * self.Ki[2]
                
            # Derivative term calculation
            self.Dterm[0] = (self.error[0] - self.previous_error[0]) * self.Kd[0]
            self.Dterm[1] = (self.error[1] - self.previous_error[1]) * self.Kd[1]
            self.Dterm[2] = (self.error[2] - self.previous_error[2]) * self.Kd[2]
    
            # Range checking for actuating velocities
            self.output_roll = BASE_ROLL + (self.Pterm[0] + self.Iterm[0] + self.Dterm[0])
            self.output_pitch = BASE_PITCH - (self.Pterm[1] + self.Iterm[1] + self.Dterm[1])
            self.output_throttle = BASE_THROTTLE + (self.Pterm[2] + self.Iterm[2] + self.Dterm[2])
    
            if self.output_roll > MAX_ROLL:     #checking range i.e. bet 1000 and 2000
                self.output_roll = MAX_ROLL
            elif self.output_roll < MIN_ROLL:
                self.output_roll = MIN_ROLL
    
            if self.output_pitch > MAX_PITCH:     #checking range i.e. bet 1000 and 2000
                self.output_pitch = MAX_PITCH
            elif self.output_pitch < MIN_PITCH:
                self.output_pitch = MIN_PITCH
    
            if self.output_throttle > MAX_THROTTLE:     #checking range i.e. bet 1000 and 2000
                self.output_throttle = MAX_THROTTLE
            elif self.output_throttle < MIN_THROTTLE:
                self.output_throttle = MIN_THROTTLE


            # Set RC message
            self.rc_message.rc_roll = abs(int(self.output_roll))
            self.rc_message.rc_pitch = abs(int(self.output_pitch))
            self.rc_message.rc_throttle = abs(int(self.output_throttle))
            self.rc_message.rc_yaw = 1500

            # Publish RC data to Raspberry Pi
            self.publish_data_to_rpi()
    
            # Accumulate errors
            self.sum_error[0] += self.error[0]
            self.sum_error[1] += self.error[1]
            self.sum_error[2] += self.error[2]
    
            # Store previous error and time
            self.previous_error[0] = self.error[0] 
            self.previous_error[1] = self.error[1] 
            self.previous_error[2] = self.error[2] 
    
            self.previous_time = self.current_time

            # Check for nearby already found alien
            near_already_found_alien = self.find_closest_already_found_aliens_coordinate()

            # Alien detection and alignment handling
            if self.aliens and not near_already_found_alien and len(self.alien_align_set_points) < 1: 
                self.alien_spotter() #It generates the setpoint at the instance where the alien was spotted initially
                self.align_mode = True #turns on align_mode

            # Alignment mode handling
            if self.align_mode:
                if abs(self.error[0]) <= 0.3 and abs(self.error[1]) <= 0.3 and abs(self.error[2]) <= 0.8:

                    #generates series of waypoints based on proximity of drone with mapped arena coordinates  
                    if not self.found_alien:
                        arena_coord = self.find_closest_coordinate() #finds closest arena coordinate (This is done for faster detection of aliens)
                        
                        if arena_coord:
                            FOUNDED_ALIENS_COORDINATES[arena_coord] = ARENA_MAPPED_DATA[arena_coord] #keep tracks of coordinates of already found aliens
                            self.found_alien = True
                        elif not self.found_alien: #generates series of waypoints until it founds nearest arena coordinate 
                            self.alien_spotter()


                    if self.alien_align_index < len(self.alien_align_set_points) - 1:
                        self.alien_align_index += 1
                    elif self.found_alien: #publishes organisms when aliens are found
                        if self.aliens:
                            organism = self.aliens[0][0]
                            self.biolocation.organism_type = organism
                            self.biolocation.whycon_x = self.drone_whycon_pose_array.poses[0].position.x
                            self.biolocation.whycon_y = self.drone_whycon_pose_array.poses[0].position.y 
                            self.biolocation.whycon_z = self.drone_whycon_pose_array.poses[0].position.z
                            self.biolocation_pub.publish(self.biolocation)
                            
                            #keep tracks of aliens found
                            self.no_of_aliens_found+=1

                            #initiates led blinking and buzzer beep
                            report_alien_thread = threading.Thread(target=self.report_alien,args=(ALIEN_TYPES[organism],))
                            report_alien_thread.start()

                            #resets the parameters for next alien detection
                            self.align_mode = False
                            self.found_alien = False
                            self.alien_align_set_points.clear()
                            self.alien_align_index = 0
                            
                            #initiates landing when no of aliens matches no to found
                            if self.no_of_aliens_found == NO_OF_ALIENS_TO_FIND:
                                self.landing()
                                self.landing_mode = True
                    
                

            elif abs(self.error[0]) <= 0.8 and abs(self.error[1]) <= 0.8 and abs(self.error[2]) <= 0.8: 
                if self.index < len(self.set_points) - 1:
                    self.index += 1
                elif not self.landing_mode: #after reaching all setpoints of search the drone  starts to landing
                    self.landing()
                    self.landing_mode = True
                else:
                    self.start_gradual_landing()

            #Publishing errors
            self.pid_error_pub.publish(
            PIDError(
                roll_error=float(self.error[0]),
                pitch_error=float(self.error[1]),
                throttle_error=float(self.error[2]),
                yaw_error=-0.0,
                zero_error=0.0
            )
        )   
 #------------------------------------------------------------------------------------------------------------------------------------           
    '''
    * Function Name: publish_data_to_rpi
    * Input: None
    * Output: None
    * Logic: 
        This function is responsible for publishing the RC (Remote Control) data to the Raspberry Pi for controlling the drone.
        It sets a constant value of 1500 to `rc_message.rc_yaw`. Then, it applies a Butterworth filter to smooth out the RC data 
        for roll, pitch, and throttle. The function maintains a sliding window of size `span` to filter the RC data. It calculates 
        the filtered signal using the Butterworth filter with specified parameters such as order, cutoff frequency, and sampling rate. 
        Finally, it publishes the filtered RC data to the Raspberry Pi.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.publish_data_to_rpi()
    '''

    def publish_data_to_rpi(self):
        # Send constant 1500 to rc_message.rc_yaw
        self.rc_message.rc_yaw = 1500

        # BUTTERWORTH FILTER
        span = 15
        for index, val in enumerate([self.rc_message.rc_roll,self.rc_message.rc_pitch,self.rc_message.rc_throttle]):
            # Append current RC value to the rolling window
            DRONE_WHYCON_POSE[index].append(val)
            # If the rolling window reaches the specified span
            if len(DRONE_WHYCON_POSE[index]) == span:
                # Remove the oldest value from the rolling window
                DRONE_WHYCON_POSE[index].pop(0)
            # If the rolling window size is not span-1, exit the function
            if len(DRONE_WHYCON_POSE[index]) != span-1:
                return
            # Butterworth filter parameters
            order = 3
            fs = 60
            fc = 5
            nyq = 0.5 * fs
            wc = fc / nyq
            # Apply Butterworth filter
            b, a = scipy.signal.butter(N=order, Wn=wc, btype='lowpass', analog=False, output='ba')
            filtered_signal = scipy.signal.lfilter(b, a, DRONE_WHYCON_POSE[index])
            # Assign filtered values to respective RC channels
            if index == 0:
                self.rc_message.rc_roll = abs(int(filtered_signal[-1]))
            elif index == 1:
                self.rc_message.rc_pitch = abs(int(filtered_signal[-1]))
            elif index == 2:
                self.rc_message.rc_throttle = abs(int(filtered_signal[-1]))


        # Publish RC data to Raspberry Pi
        self.rc_pub.publish(self.rc_message)

  
#------------------------------------------------------------------------------------------------------------------------------------#
    '''
    * Function Name: alien_spotter
    * Input: None
    * Output: None
    * Logic: 
        This function is responsible for spotting the alien's position relative to the drone's current position. 
        It calculates the error between the center of the frame and the detected alien's position in terms of 
        both x and y coordinates. Then, it converts this error from pixels to decimeters using the convert_px_to_deci function. 
        Afterward, it adjusts the drone's position by adding the error to its current position, ensuring the drone moves towards 
        the alien's location. The adjusted coordinates are appended to the alien_align_set_points list, which is used for aligning 
        the drone with the alien.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.alien_spotter()
    '''

    def alien_spotter(self):
            # Calculate error between frame center and detected alien position
            led_error_x = self.frame_center[0] - self.aliens[0][1]
            led_error_y = self.frame_center[1] - self.aliens[0][2]

            # Convert pixel error to decimeters
            led_error_dm = self.convert_px_to_deci(led_error_x,led_error_y)

            # Get drone's current position
            drone_x = np.round(self.drone_whycon_pose_array.poses[0].position.x,decimals=2)
            drone_y = np.round(self.drone_whycon_pose_array.poses[0].position.y,decimals=2)

            # Adjust drone's position based on error
            drone_x = np.round(drone_x + led_error_dm[0],decimals=2)
            drone_y = np.round(drone_y + led_error_dm[1],decimals=2)

            # Append adjusted coordinates to alien_align_set_points list
            self.alien_align_set_points.append([drone_x,drone_y,FLYING_HEIGHT])
        
      
#-----------------------------------------------------------------------------------------------------------------------------------#         
    '''
    * Function Name: search_algo
    * Input: None
    * Output: setpoints (list of lists)
    * Logic: 
        This function implements a search algorithm to generate a set of search points for the drone to explore the search area. 
        It defines the limits of the search area in x and y directions. It adjusts the drone's current position within these limits. 
        Then, it calculates the drone's takeoff point based on the adjusted position. The function iterates through the search area 
        in a zigzag pattern, skipping points based on the specified skip factors. It alternates the direction of movement 
        along the y-axis depending on whether the drone is moving towards positive or negative y coordinates. 
        It generates a list of setpoints consisting of coordinates in the search area at a constant height.
    * Example Call: 
        drone_controller = DroneController()
        search_setpoints = drone_controller.search_algo()
    '''

    def search_algo(self):
        # Define limits of search area in x and y directions
        x_limits = (-10,10)
        y_limits = (-10,10)

        # Get drone's current rounded position
        drone_x =  np.round(self.drone_whycon_pose_array.poses[0].position.x)
        drone_y =  np.round(self.drone_whycon_pose_array.poses[0].position.y)

        # Adjust drone_x and drone_y if they fall outside the limits
        drone_x = np.sign(drone_x) * min(abs(drone_x), x_limits[1])
        if abs(drone_x) < abs(x_limits[0]):
            drone_x = np.sign(drone_x) * abs(x_limits[0])

        drone_y = np.sign(drone_y) * min(abs(drone_y), y_limits[1])
        if abs(drone_y) < abs(y_limits[0]):
            drone_y = np.sign(drone_y) * abs(y_limits[0])

        # Define drone's takeoff point
        drone_takeoff_point = [int(drone_x),int(drone_y),41]

        # Define skip factors for x and y directions
        x_skip_factor = 4
        y_skip_factor = 6
        height = FLYING_HEIGHT
        setpoints = []

        # Adjust skip factor and direction based on drone's takeoff point
        x_skip_factor = x_skip_factor if drone_takeoff_point[0] < 0 else -x_skip_factor
        x_adder = 1 if drone_takeoff_point[0] < 0 else -1
        direction = 'TO_POS' if drone_takeoff_point[1] < 0 else 'TO_NEG'
        row = 0

        # Generate setpoints in a zigzag pattern within the search area
        for x in np.arange(drone_takeoff_point[0],-(drone_takeoff_point[0])+x_adder,x_skip_factor):
            row+=1
            if direction == 'TO_POS':
                for y in np.arange(y_limits[0],y_limits[1]+1,y_skip_factor):
                    setpoints.append([round(x,2),round(y,2),height])
                direction = 'TO_NEG'
                
            else:
                for y in np.arange(y_limits[1],y_limits[0]-1,-y_skip_factor):
                    setpoints.append([round(x,2),round(y,2),height])
                direction = 'TO_POS'

        return setpoints

#--------------------------------------------------------------------------------------------------------------------------------#
    '''
    * Function Name: find_closest_coordinate
    * Input: threshold (float, optional) - Threshold distance for considering a coordinate as closest (default: 1.8)
    * Output: arena_coordinate (str or None) - Closest arena coordinate or None if no coordinate is found within the threshold
    * Logic: 
        This function calculates the Euclidean distance between the drone's current position and each coordinate in the ARENA_MAPPED_DATA.
        It iterates through the coordinates and updates the closest coordinate if the calculated distance is less than the current minimum distance 
        and within the specified threshold. After iterating through all coordinates, it appends the coordinates of the closest coordinate to 
        the alien_align_set_points list for alignment purposes. It returns the key (arena_coordinate) of the closest coordinate found.
    * Example Call: 
        drone_controller = DroneController()
        closest_coord = drone_controller.find_closest_coordinate()
    '''

    def find_closest_coordinate(self,threshold=1.8):
        # Initialize variables for tracking the closest coordinate and distance
        x = np.round(self.drone_whycon_pose_array.poses[0].position.x,decimals=2)
        y = np.round(self.drone_whycon_pose_array.poses[0].position.y,decimals=2)
        arena_coordinate = None
        min_distance = float('inf') 

        # Iterate through the coordinates in the data
        for key, coordinates in ARENA_MAPPED_DATA.items():
            # Extract x, y from the coordinates
            coord_x, coord_y, _ = coordinates

            # Calculate Euclidean distance
            distance = math.sqrt((x - coord_x) ** 2 + (y - coord_y) ** 2)
      

            # Update closest coordinate if the current one is closer and within the threshold
            if distance < min_distance and distance < threshold:
                min_distance = distance
                arena_coordinate = key

        # Append coordinates of the closest coordinate to alien_align_set_points list
        if arena_coordinate is not None:
            self.alien_align_set_points.append([ARENA_MAPPED_DATA[arena_coordinate][0],ARENA_MAPPED_DATA[arena_coordinate][1],FLYING_HEIGHT])

        return arena_coordinate
    
#-----------------------------------------------------------------------------------------------------------------------------#
    '''
    * Function Name: find_closest_already_found_aliens_coordinate
    * Input: threshold (float, optional) - Threshold distance for considering a coordinate as closest (default: 5)
    * Output: arena_coordinate (str or None) - Closest already found alien's coordinate or None if no coordinate is found within the threshold
    * Logic: 
        This function calculates the Euclidean distance between the drone's current position and each coordinate in the FOUNDED_ALIENS_COORDINATES.
        It iterates through the coordinates and updates the closest coordinate if the calculated distance is less than the current minimum distance 
        and within the specified threshold. It returns the key (arena_coordinate) of the closest coordinate found if any, otherwise returns None.
    * Example Call: 
        drone_controller = DroneController()
        closest_coord = drone_controller.find_closest_already_found_aliens_coordinate()
    '''

    def find_closest_already_found_aliens_coordinate(self,threshold=5):
        # Initialize variables for tracking the closest coordinate and distance
        x = np.round(self.drone_whycon_pose_array.poses[0].position.x,decimals=2)
        y = np.round(self.drone_whycon_pose_array.poses[0].position.y,decimals=2)
        arena_coordinate = None
        min_distance = float('inf') 

        # Iterate through the coordinates in the data
        for key, coordinates in FOUNDED_ALIENS_COORDINATES.items():
            # Extract x, y from the coordinates
            coord_x, coord_y, _ = coordinates

            # Calculate Euclidean distance
            distance = math.sqrt((x - coord_x) ** 2 + (y - coord_y) ** 2)

            # Update closest coordinate if the current one is closer and within the threshold
            if distance < min_distance and distance < threshold:
                min_distance = distance
                arena_coordinate = key

        return arena_coordinate
        
#-------------------------------------------------------------------------------------------------------------------
    '''
    * Function Name: start_gradual_landing
    * Input: None
    * Output: None
    * Logic: 
        This function gradually reduces the throttle of the drone until it reaches the specified landing height above ground level.
        It decreases the throttle by the landing_speed parameter in each step, with a specified time interval between adjustments.
        If the throttle reaches or falls below the MIN_THROTTLE, it disarms the drone and breaks the loop.
        After landing, it sets the landed flag to True.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.start_gradual_landing()
    '''

    def start_gradual_landing(self):
        # Define landing parameters
        landing_height = LANDING_HEIGHT  # Height above ground level to start landing
        landing_speed = 15 # Throttle adjustment per step
        landing_interval = 0.033  # Time interval between throttle adjustments

        # Gradually reduce throttle until landing height is reached
        while self.drone_whycon_pose_array.poses[0].position.z <= landing_height:
            # Decrease throttle
            self.rc_message.rc_throttle = abs(int(self.rc_message.rc_throttle - landing_speed))

            if self.rc_message.rc_throttle <= MIN_THROTTLE:
                    self.disarm()
                    break
            # Publish throttle command
            self.rc_pub.publish(self.rc_message)
            # Wait for the next adjustment
            time.sleep(landing_interval)

        # Set alert and flag indicating the drone has landed
        self.alerter(2)
        self.landed = True


#--------------------------------------------------------------------------------------------------------------------------
    '''
    * Function Name: report_alien
    * Input: count (int) - Number of times to blink LED and beep the buzzer
    * Output: None
    * Logic: 
        This function blinks the LED and beeps the buzzer multiple times to report the presence of an alien.
        It toggles between activating the LED with a red color and the buzzer on, and deactivating them with a green LED and the buzzer off, with short delays in between.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.report_alien(3)
    '''   
    def report_alien(self,count):
        for _ in range(count):  # Blink LED and beep the buzzer three times
            # LED Red, Buzzer On
            self.rc_message.aux4 = 1500  # Red for LED
            self.rc_message.aux3 = 2000  # Activate buzzer
            self.rc_pub.publish(self.rc_message)
            time.sleep(0.2)
            # LED Green, Buzzer Off
            self.rc_message.aux4 = 2000  # Green for LED
            self.rc_message.aux3 = 1000  # Deactivate buzzer
            self.rc_pub.publish(self.rc_message)
            time.sleep(0.2)

#-------------------------------------------------------------------------------------------------------------------------------------
    '''
    * Function Name: alerter
    * Input: delay (float) - Time delay in seconds for the alert
    * Output: None
    * Logic: 
        This function activates the buzzer for a specified duration to alert the user. It sets the auxiliary channel 3 to activate the buzzer, publishes the message, waits for the specified delay duration, then deactivates the buzzer by setting the auxiliary channel 3 to a value to turn it off and publishes the message again.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.alerter(2)
    '''

    def alerter(self,delay):
           self.rc_message.aux3 = 2000  # Activate buzzer
           self.rc_pub.publish(self.rc_message)
           time.sleep(delay)
           self.rc_message.aux3 = 1000  # Deactivate buzzer
           self.rc_pub.publish(self.rc_message)
       
#-------------------------------------------------------------------------------------------------------------------------------------   
    '''
    * Function Name: landing
    * Input: None
    * Output: None
    * Logic: 
        This function prepares the drone for landing by clearing the existing set points, calculating a midway point between the current drone position and the landing point, and generating a descending trajectory from the current altitude to the landing altitude. It populates the set_points list with the waypoints for the landing trajectory.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.landing()
    '''
    def landing(self):
        #clears setpoints
        self.set_points.clear()

        #resets index
        self.index = 0

        #gets drone current position
        drone_x =  np.round(self.drone_whycon_pose_array.poses[0].position.x,decimals=2)
        drone_y =  np.round(self.drone_whycon_pose_array.poses[0].position.y,decimals=2)

        #calcualtes mid point to from current position of drone to landing point
        if [drone_x,drone_y,FLYING_HEIGHT] != DRONE_LANDING_POINT:
            midway_x = (drone_x + DRONE_LANDING_POINT[0]) / 2
            midway_y = (drone_y + DRONE_LANDING_POINT[1]) / 2
        self.set_points.append([midway_x,midway_y,FLYING_HEIGHT])

         #To generate points for landing
        for i in range(FLYING_HEIGHT,DRONE_LANDING_POINT[2]+1,2):
            self.set_points.append([DRONE_LANDING_POINT[0],DRONE_LANDING_POINT[1],i])

        

#-----------------------------------------------------------------------------------------------------------------------------------#
    '''
    * Function Name: shutdown_hook
    * Input: None
    * Output: None
    * Logic: 
        This function is called when the system is shutting down. It logs a message indicating the shutdown process and disarms the drone.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.shutdown_hook()
    '''
    def shutdown_hook(self):
        self.node.get_logger().info("Calling shutdown hook")
        self.disarm()
#------------------------------------------------------------------------------------------------------------------------------------#
        
    # Function to arm the drone 
    '''
    * Function Name: arm
    * Input: None
    * Output: None
    * Logic: 
        This function arms the drone by setting the commandbool value to True and calling the arming service asynchronously.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.arm()
    '''
    def arm(self):
        self.node.get_logger().info("Calling arm service")
        self.commandbool.value = True
        self.future = self.arming_service_client.call_async(self.commandbool)

#---------------------------------------------------------------------------------------------------------------------------------
    # Function to disarm the drone 
        
    '''
    * Function Name: disarm
    * Input: None
    * Output: None
    * Logic: 
        This function disarms the drone by setting the commandbool value to False and calling the arming service asynchronously.
    * Example Call: 
        drone_controller = DroneController()
        drone_controller.disarm()
    '''
    def disarm(self):
        self.node.get_logger().info("Calling disarm service")
        self.commandbool.value = False
        self.future = self.arming_service_client.call_async(self.commandbool)

#--------------------------------------------------------------------------------------------------------------------------------
'''
* Function Name: main
* Input: args (optional command-line arguments, default is None)
* Output: None
* Logic: 
    This is the main function of the controller node. It initializes the ROS2 node, creates a controller instance, arms the drone, generates setpoints, and enters the PID controller loop. It continuously runs the PID controller until the drone has landed or an error occurs. It also handles exceptions and ensures proper cleanup.
* Example Call: 
    main()
'''


def main(args=None):
    # Initialize ROS2 node
    rclpy.init(args=args)
    node = rclpy.create_node('controller')
    node.get_logger().info(f"Node Started")
    node.get_logger().info("Entering PID controller loop")
    controller = DroneController(node)

    controller.alerter(1) #initiates buzzer beep

    # Arm the drone
    controller.arm()
    node.get_logger().info("Armed")
    setpoints_generated = False
   
   

    try:
    
        while rclpy.ok():
            rclpy.spin_once(node)

            # Generate setpoints if not already generated
            if not setpoints_generated:
                controller.set_points = controller.search_algo()
                setpoints_generated = True

            start_time = time.time()

          
            # Execute PID controller
            controller.pid()

            # Check if drone has landed
            if controller.landed:
                break

            # Log error if WHYCON poses are not detected
            if node.get_clock().now().to_msg().sec - controller.last_whycon_pose_received_at > 1:
              node.get_logger().error("Unable to detect WHYCON poses")

            # Control loop frequency at 30 Hz
            elapsed_time = time.time() - start_time
            sleep_duration = max(0, 1.0/30 - elapsed_time)
            time.sleep(sleep_duration)

    except Exception as err:
        print(err)

    finally:
        # Clean up resources
        controller.shutdown_hook()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()











